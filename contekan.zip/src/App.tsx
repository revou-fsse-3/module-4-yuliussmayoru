import './App.css'
import { Formik } from 'formik';
import CardWithForm from './components/features/cards-with-form';

const App = () => {
  
  const handleSubmit = (values : any) => {
    console.log(values)
  }
  return (
    <>
      <Formik initialValues={{fullname:""}} onSubmit={handleSubmit}>
        <CardWithForm />
      </Formik>
    </>
  )
}

export default App
