import { InputHTMLAttributes } from "react";

type InputProps = {
    label : string;
} & InputHTMLAttributes<HTMLInputElement>

const Input = ({label, ...rest}: InputProps) => {
    return (
        <>
            <label>{label}</label>
            <input {...rest}/>
        </>
    )
}

export default Input;