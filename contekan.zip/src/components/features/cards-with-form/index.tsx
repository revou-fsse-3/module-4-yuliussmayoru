
import { useState } from "react";
import Button from "../../base/button";
import Card from "../card/Index";
import PersonalInformation from "../forms/personal-information";

const CardWithForm = () => {

    const [step, setStep] = useState(1);

    const handleNext = () => {
        if( step < 3 ) {
            setStep(step + 1)
        }
    }

    const handlePrev = () => {
        if (step > 1 ) {
            setStep(step - 1)
        }
    }

    return (
        <Card>
            <PersonalInformation />
            <Button onClick={handlePrev}>
                Previous
            </Button>
            <Button onClick={handleNext}>
                Next
            </Button>
        </Card>
    )
}

export default CardWithForm;